# iWhistle B2B Onboarding Website - Technical Specification

---

## Component Inventory

### shadcn/ui Components (Built-in)
| Component | Purpose | Customization |
|-----------|---------|---------------|
| Button | CTAs, actions | Custom gradient variant |
| Card | Feature cards, document cards | Custom border radius, shadows |
| Table | Pricing tables | Custom styling |
| Sheet | Mobile navigation | - |
| Separator | Visual dividers | - |

### Custom Components
| Component | Purpose | Props |
|-----------|---------|-------|
| Navbar | Fixed navigation | - |
| Hero | Landing section | - |
| FeatureCard | Partnership features | icon, title, description |
| TrackCard | Pilot program tracks | track data |
| MetricCard | Success metrics | value, label, description |
| DocumentCard | Downloadable docs | title, description, icon, href |
| Footer | Site footer | - |
| ScrollReveal | Animation wrapper | children, delay, direction |
| CountUp | Animated numbers | end, duration |

---

## Animation Implementation Table

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Page load sequence | Framer Motion | AnimatePresence + staggerChildren | Medium |
| Navbar scroll effect | React hooks | useState + scroll listener | Low |
| Hero content reveal | Framer Motion | motion.div with initial/animate | Medium |
| Hero gradient pulse | CSS | @keyframes animation | Low |
| Scroll-triggered reveals | Framer Motion | whileInView + viewport | Medium |
| Card hover lift | CSS/Framer | hover:translateY or whileHover | Low |
| Button hover scale | CSS | hover:scale transform | Low |
| Count-up numbers | Custom hook | useCountUp with IntersectionObserver | Medium |
| Staggered card entrance | Framer Motion | staggerChildren variant | Medium |
| Document card border glow | CSS | hover:border-color transition | Low |
| CTA button pulse | CSS | @keyframes pulse | Low |

---

## Animation Library Choices

### Primary: Framer Motion
- React-native animation library
- Excellent for scroll-triggered animations
- Built-in viewport detection (whileInView)
- Stagger animations with variants
- AnimatePresence for mount/unmount

### Secondary: CSS Animations
- Simple hover effects
- Background gradient animations
- Pulse animations
- Transitions

### Custom Hooks
- useScrollPosition: Track scroll for navbar
- useCountUp: Animated number counting
- useInView: Intersection observer wrapper

---

## Project File Structure

```
app/
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn components
│   │   ├── Navbar.tsx
│   │   ├── Hero.tsx
│   │   ├── PartnershipOverview.tsx
│   │   ├── PilotProgram.tsx
│   │   ├── SuccessMetrics.tsx
│   │   ├── Documents.tsx
│   │   ├── ContactCTA.tsx
│   │   └── Footer.tsx
│   ├── hooks/
│   │   ├── useScrollPosition.ts
│   │   └── useCountUp.ts
│   ├── components/
│   │   └── ScrollReveal.tsx
│   ├── lib/
│   │   └── utils.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── public/
│   └── images/
├── index.html
└── package.json
```

---

## Dependencies

### Core
- react
- react-dom
- typescript
- vite

### UI
- tailwindcss
- @radix-ui/react-* (via shadcn)
- lucide-react (icons)
- class-variance-authority
- clsx
- tailwind-merge

### Animation
- framer-motion

### shadcn Components to Install
- button
- card
- table
- sheet
- separator

---

## Color Variables (CSS Custom Properties)

```css
:root {
  --iwhistle-blue-primary: #0080C8;
  --iwhistle-orange-primary: #FF8C00;
  --iwhistle-blue-deep: #003D7A;
  --iwhistle-blue-light: #4DB8E8;
  --iwhistle-orange-burnt: #E67300;
}
```

---

## Tailwind Config Extensions

```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        'iwhistle-blue': '#0080C8',
        'iwhistle-orange': '#FF8C00',
        'iwhistle-deep': '#003D7A',
        'iwhistle-light': '#4DB8E8',
        'iwhistle-burnt': '#E67300',
      },
      animation: {
        'gradient-shift': 'gradientShift 8s ease infinite',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
      },
      keyframes: {
        gradientShift: {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
        },
      },
    },
  },
}
```

---

## Performance Considerations

1. Use `will-change: transform, opacity` on animated elements
2. Lazy load images below the fold
3. Use CSS transforms instead of layout properties
4. Implement `prefers-reduced-motion` support
5. Keep animations under 600ms
6. Use Intersection Observer for scroll triggers

---

## Accessibility Requirements

1. All interactive elements keyboard accessible
2. Focus states visible
3. Color contrast minimum 4.5:1
4. Semantic HTML structure
5. Alt text for images
6. Reduced motion support
